In this archive:
CS 341 Final Project.pptx	(presentation)
server-logic.nut			(example code)
readme.txt					(this file)

Extranea:
Git repository, including HTML, CSS, etc.
https://github.com/mattmc318/checkers/
